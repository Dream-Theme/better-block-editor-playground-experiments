<?php

defined( 'ABSPATH' ) || exit;

require_once __DIR__ . '/updates.php';

function better_block_theme_enqueue_frontend_styles() {
	$file_url = get_stylesheet_directory_uri() . '/assets/css/theme-styles.css';
	$version  = wp_get_theme()->get( 'Version' );

	wp_enqueue_style( 'better-block-theme-editor-styles', $file_url, [], $version );
}
add_action( 'wp_enqueue_scripts', 'better_block_theme_enqueue_frontend_styles' );
add_action( 'enqueue_block_editor_assets', 'better_block_theme_enqueue_frontend_styles' );

/**
 * Register custom block styles and pattern categories
 */
add_action(
	'init',
	function() {
		// Button sizes
		register_block_style(
			'core/button',
			[
				'name'  => 'style-1',
				'label' => __( 'XS', 'better-block-theme' ),
			]
		);
		register_block_style(
			'core/button',
			[
				'name'  => 'style-2',
				'label' => __( 'S', 'better-block-theme' ),
			]
		);
		register_block_style(
			'core/button',
			[
				'name'  => 'style-3',
				'label' => __( 'M', 'better-block-theme' ),
			]
		);
		register_block_style(
			'core/button',
			[
				'name'  => 'style-4',
				'label' => __( 'L', 'better-block-theme' ),
			]
		);
		register_block_style(
			'core/button',
			[
				'name'  => 'style-5',
				'label' => __( 'XL', 'better-block-theme' ),
			]
		);
		register_block_style(
			'core/button',
			[
				'name'  => 'style-6',
				'label' => __( 'Links', 'better-block-theme' ),
			]
		);

		// Navigation styles
		register_block_style(
			'core/navigation',
			[
				'name'         => 'default',
				'label'        => __( 'Default', 'better-block-theme' ),
				'is_default'   => true,
				'inline_style' => file_get_contents( get_stylesheet_directory() . '/assets/css/navigation-default.css' ),
				// or use 'style_handle' to enqueue a stylesheet instead of inline
			]
		);
		register_block_style(
			'core/navigation',
			[
				'name'         => 'underline',
				'label'        => __( 'Underline', 'better-block-theme' ),
				'inline_style' => file_get_contents( get_stylesheet_directory() . '/assets/css/navigation-underline.css' ),
			]
		);
		register_block_style(
			'core/navigation',
			[
				'name'         => 'elastic',
				'label'        => __( 'Elastic', 'better-block-theme' ),
				'inline_style' => file_get_contents( get_stylesheet_directory() . '/assets/css/navigation-elastic.css' ),
			]
		);
	}
);
