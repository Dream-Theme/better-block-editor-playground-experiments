<?php

defined( 'ABSPATH' ) || exit;

/**
 * Enqueue front-end and block-editor styles
 */
function better_block_theme_get_css_version( $relative_path ) {
    $full_path = get_stylesheet_directory() . $relative_path;
    return ( file_exists( $full_path ) ? filemtime( $full_path ) : false );
}

function better_block_theme_enqueue_frontend_styles() {
    $relative = '/assets/css/theme-styles.css';
    $file_url = get_stylesheet_directory_uri() . $relative;
    $version  = better_block_theme_get_css_version( $relative );

    if ( ! is_admin() && ! defined( 'REST_REQUEST' ) ) {
        wp_enqueue_style( 'better-block-theme-theme-styles', $file_url, [], $version );
    }
}
add_action( 'wp_enqueue_scripts', 'better_block_theme_enqueue_frontend_styles' );

function better_block_theme_enqueue_block_editor_styles() {
    $relative = '/assets/css/theme-styles.css';
    $file_url = get_stylesheet_directory_uri() . $relative;
    $version  = better_block_theme_get_css_version( $relative );

    wp_enqueue_style( 'better-block-theme-editor-styles', $file_url, [], $version );
}
add_action( 'enqueue_block_editor_assets', 'better_block_theme_enqueue_block_editor_styles' );


/**
 * Register custom block styles and pattern categories
 */
add_action( 'init', 'better_block_theme_register_block_styles' );
function better_block_theme_register_block_styles() {
    // Button sizes
    register_block_style(
        'core/button',
        [
            'name'  => 'style-1',
            'label' => __( 'XS', 'wpbbt' ),
        ]
    );
    register_block_style(
        'core/button',
        [
            'name'  => 'style-2',
            'label' => __( 'S', 'wpbbt' ),
        ]
    );
    register_block_style(
        'core/button',
        [
            'name'  => 'style-3',
            'label' => __( 'M', 'wpbbt' ),
        ]
    );
    register_block_style(
        'core/button',
        [
            'name'  => 'style-4',
            'label' => __( 'L', 'wpbbt' ),
        ]
    );
    register_block_style(
        'core/button',
        [
            'name'  => 'style-5',
            'label' => __( 'XL', 'wpbbt' ),
        ]
    );
    register_block_style(
        'core/button',
        [
            'name'  => 'style-6',
            'label' => __( 'Links', 'wpbbt' ),
        ]
    );

    // Navigation styles
    register_block_style(
        'core/navigation',
        [
            'name'         => 'default',
            'label'        => __( 'Default', 'wpbbt' ),
            'is_default'   => true,
            'inline_style' => file_get_contents( get_stylesheet_directory() . '/assets/css/navigation-default.css' ),
            // or use 'style_handle' to enqueue a stylesheet instead of inline
        ]
    );
    register_block_style(
        'core/navigation',
        [
            'name'         => 'underline',
            'label'        => __( 'Underline', 'wpbbt' ),
            'inline_style' => file_get_contents( get_stylesheet_directory() . '/assets/css/navigation-underline.css' ),
        ]
    );
    register_block_style(
        'core/navigation',
        [
            'name'         => 'elastic',
            'label'        => __( 'Elastic', 'wpbbt' ),
            'inline_style' => file_get_contents( get_stylesheet_directory() . '/assets/css/navigation-elastic.css' ),
        ]
    );
}
