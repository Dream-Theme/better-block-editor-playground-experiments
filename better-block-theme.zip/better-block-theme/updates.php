<?php

defined( 'ABSPATH' ) || exit;

const BETTER_BLOCK_THEME_REMOTE_METADATA = 'better_block_theme_remote_metadata';
const BETTER_BLOCK_THEME_TEMPLATE = 'better-block-theme';

/**
 * Retrieve remote metadata for this theme.
 *
 * @return array|false
 */
function better_block_theme_get_remote_metadata() {
	$cached = get_site_transient( BETTER_BLOCK_THEME_REMOTE_METADATA );

	if ( false !== $cached ) {
		return $cached;
	}

	$response = wp_remote_get(
		'https://repo.wpbbe.io/themes/list.json',
		[
			'timeout' => 10,
			'headers' => [
				'Accept' => 'application/json',
			],
		]
	);

	if ( is_wp_error( $response ) ) {
		return false;
	}

	$code = wp_remote_retrieve_response_code( $response );

	if ( 200 !== $code ) {
		return false;
	}

	$body = wp_remote_retrieve_body( $response );

	if ( empty( $body ) ) {
		return false;
	}

	$data = json_decode( $body, true );

	if ( ! is_array( $data ) ) {
		return false;
	}

	if ( empty( $data[ BETTER_BLOCK_THEME_TEMPLATE ] ) || ! is_array( $data[ BETTER_BLOCK_THEME_TEMPLATE ] ) ) {
		return false;
	}

	$theme_data = $data[ BETTER_BLOCK_THEME_TEMPLATE ];

	set_site_transient( BETTER_BLOCK_THEME_REMOTE_METADATA, $theme_data, HOUR_IN_SECONDS );

	return $theme_data;
}

add_filter(
	'pre_set_site_transient_update_themes',
	function ( $transient ) {
		if ( ! is_object( $transient ) || empty( $transient->checked ) ) {
			return $transient;
		}

		if ( ! isset( $transient->checked[ BETTER_BLOCK_THEME_TEMPLATE ] ) ) {
			return $transient;
		}

		$remote = better_block_theme_get_remote_metadata();

		if ( ! $remote || empty( $remote['version'] ) ) {
			return $transient;
		}

		$package = $remote['download_link'] ?? '';

		if ( empty( $package ) ) {
			return $transient;
		}

		$current_version = $transient->checked[ BETTER_BLOCK_THEME_TEMPLATE ];

		if ( version_compare( $remote['version'], $current_version, '<=' ) ) {
			return $transient;
		}

		$transient->response[ BETTER_BLOCK_THEME_TEMPLATE ] = [
			'theme'        => BETTER_BLOCK_THEME_TEMPLATE,
			'new_version'  => $remote['version'],
			'url'          => $remote['homepage'] ?? '',
			'package'      => $package,
			'requires'     => $remote['requires'] ?? '',
			'requires_php' => $remote['requires_php'] ?? '',
		];

		return $transient;
	}
);
