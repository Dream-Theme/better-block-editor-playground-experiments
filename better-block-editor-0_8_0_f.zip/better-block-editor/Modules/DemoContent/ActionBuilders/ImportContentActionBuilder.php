<?php

namespace BetterBlockEditor\Modules\DemoContent\ActionBuilders;

defined( 'ABSPATH' ) || exit;

class ImportContentActionBuilder extends ActionBuilderBase {

	protected function init() {
		if ( empty( $this->demo ) ) {
			// $this->add_nothing_to_import_error();

			return;
		}

		$this->setup_starting_text(
			sprintf(
				// translators: %s: template name
				esc_html_x( 'Importing %s template...', 'admin', 'the7mk2' ),
				$this->demo->title
			)
		);
	}

	protected function setup_data() {
		$actions          = [];

		if (get_template() !== 'better-block-theme') {
			$actions[] = 'install_bb_theme';
		}

		$actions[] = 'download_package';

		if ( ! get_option( 'permalink_structure' ) ) {
			$actions[] = 'setup_rewrite_rules';
		}

		$actions[] = 'turn_on_design_system';
		$actions[] = 'clear_importer_session';
		$actions[] = 'import_post_types';
		$actions[] = 'import_attachments';
		$actions[] = 'process_block_theme_data';
		$actions[] = 'download_fse_fonts';
		$actions[] = 'import_site_logo';
		$actions[] = 'cleanup';

		$actions   = array_values( $actions );

		$plugins_to_install  = [];
		$plugins_to_activate = [];

		$users = [];
		if ( isset( $this->external_data['user'] ) ) {
			$users[] = $this->external_data['user'];
		}

		$import_type = 'full_import';

		// TODO: Maybe delete.
		$tgmpa_install_protected_plugins = '';
		$demo_id          = $this->demo->id;
		$this->localize_import_data(
			compact(
				'actions',
				'users',
				'plugins_to_install',
				'plugins_to_activate',
				'demo_id',
				'import_type',
				'tgmpa_install_protected_plugins'
			)
		);
	}
}
