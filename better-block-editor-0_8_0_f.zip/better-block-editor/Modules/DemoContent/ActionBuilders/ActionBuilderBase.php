<?php

namespace BetterBlockEditor\Modules\DemoContent\ActionBuilders;

use BetterBlockEditor\Modules\DemoContent\Demo\Demo;

defined( 'ABSPATH' ) || exit;

abstract class ActionBuilderBase {

	/**
	 * @var string
	 */
	protected $starting_text = '';

	/**
	 * @var string
	 */
	protected $error;

	/**
	 * @var array
	 */
	protected $external_data;

	/**
	 * @var Demo
	 */
	protected $demo;

	abstract protected function setup_data();

	public function __construct( $demo, $external_data = [] ) {
		$this->demo = $demo;
		$this->external_data = $external_data;

		$this->init();
	}

	public function localize_data_to_js() {
		if (!empty($this->error)) {
			return;
		}

		$this->setup_data();
	}

	/**
	 * @return string
	 */
	public function get_starting_text() {
		return $this->starting_text;
	}

	public function get_error() {
		return $this->error;
	}

	protected function init() {
		// Do nothing by default.
	}

	protected function setup_starting_text( $text ) {
		$this->starting_text = $text;
	}

	protected function add_error( $error_text ) {
		$this->error = $error_text;
	}

	protected function demo() {
		return $this->demo;
	}

	protected function localize_import_data( $data = [] ) {
		wp_localize_script( WPBBE_PLUGIN_ID . '__demo-content__admin-script', 'the7ImportData', $data );
	}
}
