<?php

namespace BetterBlockEditor\Modules\DemoContent;

defined('ABSPATH') || exit;

class RemoteAPI {

    const API_DEMO_CONTENT_DOWNLOAD_URL = 'https://dev-repo.dream-dev.net/wpbbe/demo-content/';

    public static function get_demos() {
        $screenshot_base_url = '//dev-repo.dream-dev.net/demo-content/assets';
        $batch_count         = 3;

        return [
            'corporate'                       => [
                'title'               => 'Corporate',
                'id'                  => 'corporate',
                'screenshot'          => "{$screenshot_base_url}/fse-corporate.jpg",
                'link'                => 'https://templates.wpbbe.io/corporate/',
                'required_plugins'    => [
                    'the7-block-editor',
                ],
                'tags'                => [
                    'multi page',
                    'block editor',
                    'fse',
                ],
                'attachments_batch'   => $batch_count,
                'include_attachments' => true,
            ],
            'brewery'                       => [
                'title'               => 'Brewery',
                'id'                  => 'brewery',
                'screenshot'          => "{$screenshot_base_url}/fse-brewery.jpg",
                'link'                => 'https://templates.wpbbe.io/brewery/',
                'required_plugins'    => [
                    'the7-block-editor',
                    'gutena-forms',
                ],
                'tags'                => [
                    'multi page',
                    'block editor',
                    'fse',
                ],
                'attachments_batch'   => $batch_count,
                'include_attachments' => true,
            ],
            'bakery'                       => [
                'title'               => 'Bakery',
                'id'                  => 'bakery',
                'screenshot'          => "{$screenshot_base_url}/fse-bakery.jpg",
                'link'                => 'https://templates.wpbbe.io/bakery/',
                'required_plugins'    => [
                    'the7-block-editor',
                    'gutena-forms',
                ],
                'tags'                => [
                    'multi page',
                    'block editor',
                    'fse',
                ],
                'attachments_batch'   => $batch_count,
                'include_attachments' => true,
            ],
            'life-coach'                       => [
                'title'               => 'Life Coach',
                'id'                  => 'life-coach',
                'screenshot'          => "{$screenshot_base_url}/fse-life-coach.jpg",
                'link'                => 'https://templates.wpbbe.io/life-coach/',
                'required_plugins'    => [
                    'the7-block-editor',
                    'gutena-forms',
                ],
                'tags'                => [
                    'multi page',
                    'block editor',
                    'fse',
                ],
                'attachments_batch'   => $batch_count,
                'include_attachments' => true,
            ],
            'business'                       => [
                'title'               => 'Business',
                'id'                  => 'business',
                'screenshot'          => "{$screenshot_base_url}/fse-business.jpg",
                'link'                => 'https://templates.wpbbe.io/business/',
                'required_plugins'    => [
                    'the7-block-editor',
                ],
                'tags'                => [
                    'multi page',
                    'block editor',
                    'fse',
                ],
                'attachments_batch'   => $batch_count,
                'include_attachments' => true,
            ],
        ];
    }

    /**
	 * This method try to download demo content with $id and put it to $target_path.
	 * Creates $target_path dir if it is not exists. Dummy content zip archive will be unzipped.
	 *
	 * @param string $id
	 * @param string $target_dir
	 * @param string $req_url
	 *
	 * @return string|\WP_Error Path where dummy content files is located on success or WP_Error on failure.
	 */
	public static function download_demo( $id, $target_dir, $req_url = '' ) {
        /**
         * @var \WP_Filesystem_Base $wp_filesystem
         */
		global $wp_filesystem;

        $strings = [
            'fs_unavailable' => __( 'File system is unavailable.', 'the7mk2' ),
            'fs_no_folder'   => __( 'No folder found at %s.', 'the7mk2' ),
            'download_failed' => __( 'Failed to download template content. HTTP response code: %d', 'the7mk2' ),
        ];

		if ( ! $wp_filesystem && ! WP_Filesystem() ) {
			return new \WP_Error( 'fs_unavailable', $strings['fs_unavailable'] );
		}

		if ( is_wp_error( $wp_filesystem->errors ) && $wp_filesystem->errors->get_error_code() ) {
			return $wp_filesystem->errors;
		}

		$request_url =  self::API_DEMO_CONTENT_DOWNLOAD_URL . '/' . sanitize_file_name( $id . '.zip' );
		$remote_response  = wp_safe_remote_get(
			$request_url,
			[
				'timeout'    => 300,
				'user-agent' => 'WordPress/' . get_bloginfo( 'version' ) . '; ' . network_site_url(),
			]
		);

		if ( is_wp_error( $remote_response ) ) {
			return $remote_response;
		}

		$response_code = (int) wp_remote_retrieve_response_code( $remote_response );

		if ( ! is_array( $remote_response ) || 200 !== $response_code ) {
			return new \WP_Error(
				'download_failed',
				sprintf( $strings['download_failed'], $response_code )
			);
		}

		wp_mkdir_p( $target_dir );

		$file_content  = wp_remote_retrieve_body( $remote_response );
		$zip_file_name = trailingslashit( $target_dir ) . "{$id}.zip";
		$wp_filesystem->put_contents( $zip_file_name, $file_content );

		$unzip_result = unzip_file( $zip_file_name, $target_dir );
		if ( is_wp_error( $unzip_result ) ) {
			return $unzip_result;
		}

		$dummy_dir = trailingslashit( $target_dir ) . $id;

		if ( ! is_dir( $dummy_dir ) ) {
			return new \WP_Error( 'fs_no_folder', sprintf( $strings['fs_no_folder'], $dummy_dir ) );
		}

		return $dummy_dir;
	}
}
