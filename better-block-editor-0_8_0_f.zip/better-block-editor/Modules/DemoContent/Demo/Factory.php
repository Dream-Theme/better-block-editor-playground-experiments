<?php

namespace BetterBlockEditor\Modules\DemoContent\Demo;

use BetterBlockEditor\Modules\DemoContent\RemoteAPI;
use BetterBlockEditor\Modules\DemoContent\Demo\Demo;

defined( 'ABSPATH' ) || exit;

class Factory {

	/**
	 * @param array $demo
	 * @param array $history
	 *
	 * @return Demo
	 */
	public static function create( $demo_id ) {
        $demos = RemoteAPI::get_demos();
        $demo = $demos[ $demo_id ] ?? [];
		$history = [];

		return new Demo( $demo, $history );
	}
}
