<?php

namespace BetterBlockEditor\Modules\DemoContent\Demo;

defined( 'ABSPATH' ) || exit;

class Demo {

	const DEMO_STATUS_FULL_IMPORT    = 'full_import';
	const DEMO_STATUS_PARTIAL_IMPORT = 'partial_import';
	const DEMO_STATUS_NOT_IMPORTED   = 'not_imported';

	/**
	 * @var bool
	 */
	public $post_types_imported;

	/**
	 * @var bool
	 */
	public $theme_options_imported;

	/**
	 * @var bool
	 */
	public $attachments_imported;

	/**
	 * @var bool
	 */
	public $sliders_imported;

	/**
	 * @var string
	 */
	protected $import_status;

	/**
	 * @var The7_Demo_Content_TGMPA
	 */
	protected $plugins;

	/**
	 * @var array
	 */
	protected $fields = [];

	public function __construct( $demo, $history ) {
		$this->setup_fields( $demo );
		$this->refresh_import_status( $history );
	}

	public function refresh_import_status() {
		$this->post_types_imported    = false;
		$this->attachments_imported   = false;

		$this->import_status = $this->get_import_status();
	}

	/**
	 * @return string
	 */
	public function get_import_status_text() {
		$text = '';
		if ( $this->import_status === static::DEMO_STATUS_FULL_IMPORT ) {
			$text = '(' . esc_html__( 'fully imported', 'the7mk2' ) . ')';
		}

		return '<span class="demo-import-status">' . $text . '</span>';
	}

	/**
	 * @return bool
	 */
	public function import_allowed() {
		return true;
	}

	/**
	 * @return bool
	 */
	public function partially_imported() {
		return in_array(
			$this->import_status,
			[ static::DEMO_STATUS_PARTIAL_IMPORT, static::DEMO_STATUS_FULL_IMPORT ],
			true
		);
	}

	/**
	 * @return The7_Demo_Content_TGMPA
	 */
	public function plugins() {
		// if ( null === $this->plugins ) {
		// 	$this->plugins = new The7_Demo_Content_TGMPA( $this->required_plugins );
		// }

		return $this->plugins;
	}

	public function get_demo_uploads_dir() {
		$wp_uploads = wp_get_upload_dir();

		return trailingslashit( $wp_uploads['basedir'] ) . "wpbbe-demo-content-tmp/{$this->id}";
	}

	public function get_import_xml_file() {
		return $this->get_demo_uploads_dir() . '/full-content.xml';
	}

	public function get_import_meta_file() {
		return $this->get_demo_uploads_dir() . '/site-meta.json';
	}

	public function get_import_meta( $key = null ) {
		$meta_file = $this->get_import_meta_file();
		if ( ! is_file( $meta_file ) ) {
			return [];
		}

		$meta = json_decode( file_get_contents( $meta_file ), true );
		if ( ! is_array( $meta ) ) {
			return [];
		}

		if ( $key === null ) {
			return $meta;
		}

		if ( array_key_exists( $key, $meta ) ) {
			return $meta[ $key ];
		}

		return null;
	}

	/**
	 * @param string $prop
	 *
	 * @return mixed|null
	 */
	public function __get( $prop ) {
		if ( array_key_exists( $prop, $this->fields ) ) {
			return $this->fields[ $prop ];
		}

		return null;
	}

	/**
	 * Magic setter for demo fields and known properties.
	 *
	 * Only allows setting keys that exist in {@see $this->fields} and
	 * casts values to the expected types. Attempts to set unknown
	 * properties are reported via _doing_it_wrong to aid debugging.
	 *
	 * @param string $name
	 * @param mixed  $value
	 */
	public function __set( $name, $value ) {
		// If it's one of the declared fields, store it with proper casting.
		if ( array_key_exists( $name, $this->fields ) ) {
			switch ( $name ) {
				case 'include_attachments':
					$this->fields[ $name ] = (bool) $value;
					break;
				case 'attachments_batch':
					$this->fields[ $name ] = (int) $value;
					break;
				case 'required_plugins':
				case 'tags':
					$this->fields[ $name ] = (array) $value;
					break;
				default:
					$this->fields[ $name ] = $value;
			}
			return;
		}

		// Unknown property — report to help debugging.
		if ( function_exists( '_doing_it_wrong' ) ) {
			_doing_it_wrong( __CLASS__ . '::__set', sprintf( /* translators: %s: property name */ esc_html__( 'Attempt to set unknown property "%s" on Demo object.', 'the7mk2' ), $name ), '1.0' );
		} else {
			trigger_error( sprintf( 'Attempt to set unknown property "%s" on %s', $name, __CLASS__ ), E_USER_NOTICE );
		}
	}

	/**
	 * Magic isset handler for demo fields and protected properties.
	 *
	 * Called when isset() or empty() is used on inaccessible properties.
	 *
	 * @param string $name
	 *
	 * @return bool
	 */
	public function __isset( $name ) {
		// Field exists in fields array
		if ( array_key_exists( $name, $this->fields ) ) {
			return null !== $this->fields[ $name ];
		}

		// If a class property exists (protected/private), check it here.
		if ( property_exists( $this, $name ) ) {
			return isset( $this->$name );
		}

		return false;
	}

	/**
	 * @return string
	 */
	protected function get_import_status() {
		$entire_demo_is_imported    = $this->post_types_imported && $this->attachments_imported;

		if ( $entire_demo_is_imported ) {
			return static::DEMO_STATUS_FULL_IMPORT;
		}

		return static::DEMO_STATUS_NOT_IMPORTED;
	}

	/**
	 * @param array $fields
	 */
	protected function setup_fields( $fields ) {
		$allowed_fields = [
			'title'               => '',
			'id'                  => '',
			'include_attachments' => false,
			'screenshot'          => '',
			'link'                => '',
			'attachments_batch'   => 999,
			'required_plugins'    => [],
			'tags'                => [],
		];

		$fields       = array_intersect_key( (array) $fields, $allowed_fields );
		$this->fields = wp_parse_args( $fields, $allowed_fields );
	}
}
