<?php

namespace BetterBlockEditor\Modules\DemoContent\AjaxHandlers;

use BetterBlockEditor\Modules\DemoContent\Demo\Factory as DemoFactory;
use BetterBlockEditor\Modules\DemoContent\Demo\Demo;
use BetterBlockEditor\Modules\DemoContent\Module;
use BetterBlockEditor\Modules\DemoContent\RemoteAPI;
use BetterBlockEditor\Modules\DemoContent\Importers\ContentImporter;
use BetterBlockEditor\Modules\DemoContent\Importers\WPSettingsImporter;
use BetterBlockEditor\Modules\DemoContent\Importers\FSEImporter;
use BetterBlockEditor\Modules\DemoContent\Trackers\ContentTracker;
use BetterBlockEditor\Core\Settings;

defined( 'ABSPATH' ) || exit;

class ImportContentAjaxHandler extends AjaxHandlerBase {

    public static function register() {
        add_action( 'wp_ajax_wpbbe_import_demo', [ self::class, 'ajax_import_demo' ] );
    }

    public static function ajax_import_demo() {
        if ( ! check_ajax_referer( 'wpbbe_import_demo', false, false ) || ! current_user_can( Module::CAPABILITY ) ) {
			wp_send_json_error( [ 'error_msg' => '<p>' . esc_html_x( 'Insufficient user rights.', 'admin', 'the7mk2' ) . '</p>' ] );
		}

		if ( empty( $_POST['sub_action'] ) ) {
			wp_send_json_error( [ 'error_msg' => '<p>' . esc_html_x( 'Unable to find demo.', 'admin', 'the7mk2' ) . '</p>' ] );
		}

		wp_raise_memory_limit( 'admin' );

		$import_type = isset( $_POST['import_type'] ) ? $_POST['import_type'] : 'full_import';
		$demo_id     = isset( $_POST['content_part_id'] ) ? sanitize_key( $_POST['content_part_id'] ) : '';

		$wp_uploads         = wp_get_upload_dir();
		$import_content_dir = trailingslashit( $wp_uploads['basedir'] ) . "wpbbe-demo-content-tmp/{$demo_id}";

        $demo = DemoFactory::create( $demo_id );
		if ( ! $demo ) {
			wp_send_json_error( [ 'error_msg' => '<p>' . esc_html_x( 'Unable to recognise demo.', 'admin', 'the7mk2' ) . '</p>' ] );
		}

		$retval = null;

		$sub_action = isset( $_POST['sub_action'] ) ? sanitize_key( wp_unslash( $_POST['sub_action'] ) ) : '';
		$method     = $sub_action ? 'sub_action_' . $sub_action : '';
		if ( $method && method_exists( self::class, $method ) ) {
			$content_tracker = new ContentTracker( $demo_id );

			$retval = \call_user_func( [ self::class, $method ], $demo, $import_type, $content_tracker );
		} else {
			wp_send_json_error( [ 'error_msg' => '<p>' . esc_html_x( 'Unknown action.', 'admin', 'the7mk2' ) . '</p>' ] );
		}

		// if ( $import_manager->has_errors() ) {
		// 	wp_send_json_error( [ 'error_msg' => $import_manager->get_errors_string() ] );
		// }

		wp_send_json_success( $retval );
    }

	/**
	 * Handlers extracted from switch-case. Each method returns a value to be sent back (or null).
	 * Signature: ($import_manager, $demo, $import_type, $content_tracker)
	 */

	private static function sub_action_download_package( $demo, $import_type, $content_tracker ) {
		$source = isset( $_POST['demo_page_url'] ) ? esc_url_raw( wp_unslash( $_POST['demo_page_url'] ) ) : '';
		$import_content_dir = $demo->get_demo_uploads_dir();
		$item               = basename( $import_content_dir );
		$download_dir       = dirname( $import_content_dir );
		$download_response  = RemoteAPI::download_demo( $item, $download_dir, $source );

		if ( is_wp_error( $download_response ) ) {
			$error = $download_response->get_error_message();

			// $this->add_error( $error );

			return false;
		}

		// $this->importer->log_reset();

		return trailingslashit( $download_response );
	}

	private static function sub_action_turn_on_design_system( $demo, $import_type, $content_tracker ) {
		if ( class_exists( '\BetterBlockEditor\Modules\DesignSystemParts\Module' ) ) {
			$module_identifier = \BetterBlockEditor\Modules\DesignSystemParts\Module::MODULE_IDENTIFIER;
			update_option( WPBBE_PLUGIN_ID . '__module__' . $module_identifier . '__enabled', true );
			$option_name = Settings::build_module_option_name( $module_identifier );
			$value = [
				'active-parts' => [
					'color'      => 1,
					'typography' => 1,
				],
			];

			update_option( $option_name, $value );
		}

		return null;
	}

	private static function sub_action_clear_importer_session( $demo, $import_type, $content_tracker ) {
		ContentImporter::clear_session();
		return null;
	}

	private static function sub_action_setup_rewrite_rules( $demo, $import_type, $content_tracker ) {
		$permalink_structure = '/%year%/%monthnum%/%day%/%postname%/';
		$permalink_structure = sanitize_option( 'permalink_structure', $permalink_structure );

		global $wp_rewrite;
		$wp_rewrite->set_permalink_structure( $permalink_structure );
		return null;
	}

	private static function sub_action_import_post_types( Demo $demo, $import_type, $content_tracker ) {
		$file_to_import = $demo->get_import_xml_file();

		if ( ! is_file( $file_to_import ) ) {
			// $this->add_error(
			// 	esc_html(
			// 		__( 'The XML file containing the dummy content is not available or could not be read in the file:', 'the7mk2' ) . ' ' . $file_name
			// 	)
			// );

			return false;
		}

		if ( $content_tracker ) {
			$content_tracker->track_imported_items();
		}

		$menus = wp_get_nav_menus();
		if ( ! empty( $menus ) ) {
			foreach ( $menus as $menu ) {
				$updated = false;
				$i       = 0;

				while ( ! is_numeric( $updated ) ) {
					++$i;
					$args['menu-name']   = __( 'Previously used menu', 'the7mk2' ) . ' ' . $i;
					$args['description'] = $menu->description;
					$args['parent']      = $menu->parent;

					$updated = wp_update_nav_menu_object( $menu->term_id, $args );

					if ( $i > 100 ) {
						$updated = 1;
					}
				}
			}
		}

		/**
		 * Fix Fatal Error while process orphaned variations.
		 */
		// remove_filter( 'post_type_link', [ '\WC_Post_Data', 'variation_post_link' ] );
		// add_filter( 'post_type_link', [ $this, 'variation_post_link' ], 10, 2 );

		$importer = new ContentImporter();
		$importer->log_reset();

		$demo_title = isset( $demo->title ) ? $demo->title : 'Demo';
		$importer->log_add( "Importing {$demo_title}\n" );

		$start = microtime( true );

		$fse_importer = new FSEImporter( $importer, $content_tracker );
		$fse_importer->do_before_importing_content();

		$importer->fetch_attachments = false;
		$importer->import( $file_to_import );

		$importer->log_add( 'Content was imported in: ' . ( microtime( true ) - $start ) . "\n" );

		$import_meta = $demo->get_import_meta();

		$importer->log_add( 'WP settings importing...' );

		$wp_settings_importer = new WPSettingsImporter( $importer, $content_tracker );

		if ( ! empty( $import_meta['wp_settings'] ) ) {
			$wp_settings_importer->import_settings( $import_meta['wp_settings'] );

			$importer->log_add( 'WP settings were imported.' );
		}

		if ( ! empty( $import_meta['nav_menu_locations'] ) ) {
			$wp_settings_importer->import_menu_locations( $import_meta['nav_menu_locations'] );

			$importer->log_add( 'Menu locations were imported.' );
		}

		if ( ! empty( $import_meta['widgets_settings'] ) ) {
			$wp_settings_importer->import_widgets( $import_meta['widgets_settings'] );

			$importer->log_add( 'Widgets were imported.' );
		}

		$importer->log_add( 'Done' );

		 if ( $content_tracker && is_object( $content_tracker ) ) {
		 	$content_tracker->add( 'post_types', true );
		 }

		return null;
	}

	private static function sub_action_import_post_types_builder_data( $demo, $import_type, $content_tracker ) {
		// $import_manager->import_the7_core_post_types_builder_data();
		return null;
	}

	private static function sub_action_import_attachments( $demo, $import_type, $content_tracker ) {
		$file_to_import = $demo->get_import_xml_file();

		if ( ! is_file( $file_to_import ) ) {
			// $this->add_error(
			// 	esc_html(
			// 		__( 'The XML file containing the dummy content is not available or could not be read in the file:', 'the7mk2' ) . ' ' . $file_name
			// 	)
			// );

			return false;
		}

		if ( $content_tracker && is_object( $content_tracker ) && method_exists( $content_tracker, 'track_imported_items' ) ) {
			$content_tracker->track_imported_items();
		}

		add_filter( 'wp_import_tags', '__return_empty_array' );
		add_filter( 'wp_import_categories', '__return_empty_array' );
		add_filter( 'wp_import_terms', '__return_empty_array' );

		$importer = new ContentImporter();
		$importer->read_processed_data_from_cache();
		$retval = $importer->import_batch( $file_to_import, (int) $demo->attachments_batch );

		$widgets = get_option( 'widget_text', [] );
		if ( $widgets ) {
			$widgets_str = wp_json_encode( $widgets );

			$url_remap = $importer->url_remap;
			uksort( $url_remap, [ $importer, 'cmpr_strlen' ] );

			foreach ( $url_remap as $old_url => $new_url ) {
				$old_url     = str_replace( '"', '', wp_json_encode( $old_url ) );
				$new_url     = str_replace( '"', '', wp_json_encode( $new_url ) );
				$widgets_str = str_replace( $old_url, $new_url, $widgets_str );
			}

			update_option( 'widget_text', json_decode( $widgets_str, true ) );
		}

		// $wc_importer = new The7_WC_Importer( $this->importer );
		// $wc_importer->fix_product_cat_thumbnail_id();

		if ( isset( $retval['imported'] ) && $content_tracker && is_object( $content_tracker ) ) {
			$content_tracker->add( 'attachments_in_process', $retval['imported'] );
		}

		if ( isset( $retval['left'] ) && $retval['left'] === 0 && $content_tracker && is_object( $content_tracker ) ) {
			$content_tracker->add( 'attachments', $demo->include_attachments ? 'original' : 'placeholders' );
			if ( method_exists( $content_tracker, 'remove' ) ) {
				$content_tracker->remove( 'attachments_imported' );
			}
		}

		return $retval;
	}

	private static function sub_action_import_site_logo( $demo, $import_type, $content_tracker ) {
		$importer = new ContentImporter();
		$importer->read_processed_data_from_cache();

		$wp_settings_importer = new WPSettingsImporter( $importer, $content_tracker );

		$site_identity = $demo->get_import_meta( 'site_identity' );

		if ( ! empty( $site_identity['custom_logo'] ) ) {
			$wp_settings_importer->import_custom_logo(
				$importer->get_processed_post( (int) $site_identity['custom_logo'] )
			);
		}

		if ( ! empty( $site_identity['site_icon'] ) ) {
			$wp_settings_importer->import_site_icon(
				$importer->get_processed_post( (int) $site_identity['site_icon'] )
			);
		}
		return null;
	}

	private static function sub_action_process_block_theme_data( $demo, $import_type, $content_tracker ) {
		$importer = new ContentImporter();
		$importer->read_processed_data_from_cache();

		$fse_importer = new FSEImporter( $importer, $content_tracker );
		$fse_importer->remap_post_ids_and_urls_in_blocks();
		$fse_importer->import_block_editor_settings( $demo->get_import_meta() );
		// if ( class_exists( '\\The7\\Mods\\Compatibility\\Gutenberg\\Block_Theme\\The7_FSE_Font_Manager' ) ) {
		// 	$cls = '\\The7\\Mods\\Compatibility\\Gutenberg\\Block_Theme\\The7_FSE_Font_Manager';
		// 	$font_manager = \call_user_func( [ $cls, 'instance' ] );
		// 	if ( is_object( $font_manager ) && method_exists( $font_manager, 'reset_fonts_to_download' ) ) {
		// 		$font_manager->reset_fonts_to_download();
		// 	}
		// }

		return null;
	}

	private static function sub_action_cleanup( $demo, $import_type, $content_tracker ) {
		ContentImporter::clear_session();

		$wp_uploads = wp_get_upload_dir();

		$dir_to_delete = dirname( $demo->get_demo_uploads_dir() );
		if ( untrailingslashit( $wp_uploads['basedir'] ) === untrailingslashit( $dir_to_delete ) ) {
			return false;
		}

		if ( false === strpos( $dir_to_delete, $wp_uploads['basedir'] ) ) {
			return false;
		}

		global $wp_filesystem;

		if ( ! $wp_filesystem && ! WP_Filesystem() ) {
			return false;
		}

		$wp_filesystem->delete( $dir_to_delete, true );

		flush_rewrite_rules();
		return [
			'status' => $demo->get_import_status_text(),
		];
	}

	// Minimal stubs for helpers previously referenced via $this
	private static function get_step_2_post_links( $post_id ) {
		return [];
	}

	private static function determine_post_import_actions( $post_id, $demo ) {
		return [];
	}

	private static function send_admin_notice( $type, $title ) {
		// Intentionally left minimal; integrate with admin notices system if needed.
	}
}
