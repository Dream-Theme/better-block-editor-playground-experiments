<?php

namespace BetterBlockEditor\Modules\DemoContent\AjaxHandlers;

use BetterBlockEditor\Modules\DemoContent\Module;
use BetterBlockEditor\Modules\DemoContent\Demo\Factory as DemoFactory;
use BetterBlockEditor\Modules\DemoContent\Trackers\ContentTracker;

defined( 'ABSPATH' ) || exit;

class KeepContentAjaxHandler extends AjaxHandlerBase {

	public static function register() {
        add_action( 'wp_ajax_wpbbe_keep_content', [ self::class, 'ajax_keep_content' ] );
    }

	public static function ajax_keep_content() {
		if ( ! check_ajax_referer( 'wpbbe_keep_demo_content', false, false ) || ! current_user_can( Module::CAPABILITY ) ) {
			wp_send_json_error( [ 'error_msg' => '<p>' . esc_html_x( 'Insufficient user rights.', 'admin', 'the7mk2' ) . '</p>' ] );
		}

		$demo_id = isset( $_POST['demo_id'] ) ? sanitize_key( $_POST['demo_id'] ) : '';
		$demo    = DemoFactory::create( $demo_id );
		if ( ! $demo ) {
			wp_send_json_error( [ 'error_msg' => '<p>' . esc_html_x( 'Unable to recognise demo.', 'admin', 'the7mk2' ) . '</p>' ] );
		}

		$content_tracker = new ContentTracker( $demo_id );
		$content_tracker->keep_demo_content();

		// Since we changed content tracker history.
		$demo->refresh_import_status();

		// Set a one-time success notice for the current user to be shown on page load.
		set_transient( Module::MENU_PAGE_SLUG . '_keep_content_notice', 1, MINUTE_IN_SECONDS * 2 );

		wp_send_json_success(
			[
				'status' => $demo->get_import_status_text(),
			]
		);
	}
}
