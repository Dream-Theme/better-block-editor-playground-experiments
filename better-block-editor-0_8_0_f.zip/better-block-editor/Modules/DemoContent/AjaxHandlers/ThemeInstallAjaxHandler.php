<?php

namespace BetterBlockEditor\Modules\DemoContent\AjaxHandlers;

defined( 'ABSPATH' ) || exit;

class ThemeInstallAjaxHandler extends AjaxHandlerBase {

	public static function register() {
		add_action( 'wp_ajax_wpbbe_install_bb_theme', [ self::class, 'install_theme' ] );
	}

	public static function install_theme() {
		$slug = 'better-block-theme';

		$theme = wp_get_theme( $slug );

		// If theme is already installed
		if ( $theme && $theme->exists() ) {
			// If it's not the active theme, activate it
			if ( get_template() !== $slug ) {
				switch_theme( $slug );
				wp_send_json_success( [ 'message' => __( 'Theme activated.', 'wpbbe' ) ] );
			} else {
				wp_send_json_success( [ 'message' => __( 'Theme already installed and active.', 'wpbbe' ) ] );
			}
			return;
		}

		if ( ! function_exists( 'wp_ajax_install_theme' ) ) {
			wp_send_json_error( [ 'message' => __( 'Theme installation function not found.', 'wpbbe' ) ] );
			return;
		}

		// Not installed — proceed with installation
		$_POST['slug'] = $slug;
		add_filter( 'themes_api', [ self::class, 'override_theme_information_api' ], 10, 3 );
		wp_ajax_install_theme();
		switch_theme( $slug );
	}

	public static function override_theme_information_api( $res, $action, $args ) {
		if ( ! $res && isset( $args->slug ) && $args->slug === 'better-block-theme' ) {
			$res = (object) [
				'name' => 'Better Block Theme',
				'slug' => 'better-block-theme',
				'version' => '1.0',
				'preview_url' => 'https://wp-themes.com/twentytwentyfive/',
				'author' => [
					'name' => 'Dream Theme',
				],
				'screenshot_url' => '//ts.w.org/wp-content/themes/twentytwentyfive/screenshot.png?ver=1.3',
				'rating' => 80,
				'num_ratings' => 10,
				'reviews_url' => 'https://wordpress.org/support/theme/twentytwentyfive/reviews/',
				'downloaded' => 2326233,
				'last_updated' => '2025-08-05',
				'last_updated_time' => '2025-08-05 19:30:35',
				'creation_time' => '2024-11-13 00:56:57',
				'homepage' => 'https://wordpress.org/themes/twentytwentyfive/',
				'sections' => [],
				'download_link' => 'https://dev-repo.dream-dev.net/wpbbe/theme/better-block-theme.zip',
				'tags' => [],
				'requires' => '6.7',
				'requires_php' => '7.2',
				'is_commercial' => false,
				'external_support_url' => false,
				'is_community' => true,
				'external_repository_url' => '',
			];
		}

		return $res;
	}
}
