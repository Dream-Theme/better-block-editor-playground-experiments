<?php

namespace BetterBlockEditor\Modules\DemoContent\AjaxHandlers;

defined( 'ABSPATH' ) || exit;

abstract class AjaxHandlerBase {

    abstract public static function register();

}
