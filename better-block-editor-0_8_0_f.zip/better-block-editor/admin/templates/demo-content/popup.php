<?php

defined('ABSPATH') || exit;

?>
<style>
	#bbe-popup-window .welcome-panel-column-container {
		display: flex;
		flex-direction: column;
	}
	#bbe-popup-window .welcome-panel-content {
		min-height: auto;
	}
    #registration-splash-screen-container .welcome-panel-header {
        background: url("../images/admin-splash-bg.jpg") no-repeat left center;
    }

    #bbe-popup-overlay {
        position: fixed;
        top: 0;
        left: 0;
        background: rgba(0, 0, 0, 0.7);
        right: 0;
        bottom: 0;
        z-index: 1;
    }

    #bbe-popup-window {
        position: fixed;
		top: 50%;
		left: 50%;
		transform: translate(-50%, -50%);
        margin: 0 32px 0 0;
        max-width: 1059px;
        z-index: 9;
        box-shadow: 0 0 7px rgba(0, 0, 0, 0.5);
    }

    @media screen and (max-width: 782px) {
        #bbe-popup-window {
            position: absolute;
            top: 24px;
        }
    }

    body.bbe-modal-open ul#adminmenu a.wp-has-current-submenu:after,
    body.bbe-modal-open ul#adminmenu>li.current>a.current:after {
        border-right-color: rgb(72, 72, 72) !important;
    }

    #registration-splash-screen-container.welcome-panel {
        margin: 0;
    }

    #registration-splash-screen-container .welcome-panel-close,
    #registration-splash-screen-container .welcome-panel-close:before {
        color: white;
    }

    #registration-splash-screen-container .welcome-panel-close:hover,
    #registration-splash-screen-container .welcome-panel-close:hover:before {
        color: rgb(103, 222, 235);
    }

    #registration-splash-screen-container .welcome-panel-header {
        padding: 48px 300px 48px 48px;
        background-size: cover;
    }

    #registration-splash-screen-container .welcome-panel-header h2,
    #registration-splash-screen-container .welcome-panel-header p {
        color: white;
    }

    #registration-splash-screen-container .welcome-panel-header-image {
        right: 100px;
        top: 30px;
        bottom: 30px;
        width: auto;
        height: auto;
        left: auto;
    }

    #registration-splash-screen-container .welcome-panel-header-image svg {
        height: 100%;
        width: auto;
    }

    #registration-splash-screen-container [class*=welcome-panel-icon] {
        background-color: #e0eefb;
    }

    #registration-splash-screen-container [class*=welcome-panel-icon] svg {
        width: 40%;
        height: 40%;
        margin: 30%;
        color: #1690e1;
    }

    #registration-splash-screen-container .button-primary {
        background-color: #1690e1;
        border-color: #1690e1;
    }

    #registration-splash-screen-container .button-primary:hover {
        background-color: #137abe;
        border-color: #137abe;
    }

    #registration-splash-screen-container .button-secondary {
        color: #1690e1;
        border-color: #1690e1;
        background-color: transparent;
    }

    #registration-splash-screen-container .button-secondary:hover {
        color: #137abe;
        border-color: #137abe;
        background-color: #e0eefb;
    }

	#registration-splash-screen-container .welcome-panel-buttons {
		display: flex;
		justify-content: space-between;
	}

	#registration-splash-screen-container .welcome-panel-column-content {
		max-width: 300px;
	}

    @media screen and (max-width: 782px) {
        #registration-splash-screen-container .welcome-panel-header {
            padding: 48px;
        }

        #registration-splash-screen-container .welcome-panel-header-image svg {
            display: none;
        }
    }
</style>

<div id="registration-splash-screen-popup" style="display:none;">
    <div id="registration-splash-screen-container" class="welcome-panel">
        <a class="bbe-popup-dismiss welcome-panel-close dismiss-notice" href="#"
            aria-label="Dismiss the welcome panel"><?php echo esc_html_x('Dismiss', 'admin', 'the7mk2'); ?></a>
        <div class="welcome-panel-content">
            <div class="welcome-panel-column-container">
                <div class="welcome-panel-column">
                    <div class="welcome-panel-icon">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
                            class="bi bi-box-arrow-down" viewBox="0 0 16 16">
                            <path fill-rule="evenodd"
                                d="M3.5 10a.5.5 0 0 1-.5-.5v-8a.5.5 0 0 1 .5-.5h9a.5.5 0 0 1 .5.5v8a.5.5 0 0 1-.5.5h-2a.5.5 0 0 0 0 1h2A1.5 1.5 0 0 0 14 9.5v-8A1.5 1.5 0 0 0 12.5 0h-9A1.5 1.5 0 0 0 2 1.5v8A1.5 1.5 0 0 0 3.5 11h2a.5.5 0 0 0 0-1h-2z"></path>
                            <path fill-rule="evenodd"
                                d="M7.646 15.854a.5.5 0 0 0 .708 0l3-3a.5.5 0 0 0-.708-.708L8.5 14.293V5.5a.5.5 0 0 0-1 0v8.793l-2.146-2.147a.5.5 0 0 0-.708.708l3 3z"></path>
                        </svg>
                    </div>
                    <div class="welcome-panel-column-content">
                        <h3><?php echo esc_html_x('Import Template', 'admin', 'the7mk2'); ?></h3>
                        <p><?php echo esc_html_x('This option will import the chosen Template and the Better Block Theme with full content compatibility.', 'admin', 'the7mk2'); ?></p>
                        <div class="welcome-panel-buttons">
							<button type="submit" class="button button-secondary bbe-popup-dismiss" title="<?php echo esc_html_x('Skip', 'admin', 'the7mk2'); ?>"><?php echo esc_html_x('Cancel', 'admin', 'the7mk2'); ?></button>
                            <a href="<?php echo admin_url('theme-install.php?browse=popular'); ?>" class="button button-primary install-theme" data-nonce="<?php echo esc_attr( wp_create_nonce( 'updates' ) ); ?>">
                                <?php echo esc_html_x('Import', 'admin', 'the7mk2'); ?>
							</a>
						</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
