<?php

defined( 'ABSPATH' ) || exit;

// Hardcoded demo data array
$demo_websites = BetterBlockEditor\Modules\DemoContent\RemoteAPI::get_demos();
$step2_url = BetterBlockEditor\Modules\DemoContent\Module::get_admin_step2_url();

// Count total and by category
$total_count = count($demo_websites);
$block_editor_count = count(array_filter($demo_websites, function($demo) { return in_array( 'fse', $demo['tags'], true ); }));
$shop_count = count(array_filter($demo_websites, function($demo) { return in_array( 'shop', $demo['tags'], true ); }));
$import_history = \BetterBlockEditor\Modules\DemoContent\Trackers\TrackerBase::get_all_demo_history();
$imported_count = count($import_history);
?>

<div class="wp-filter websites-filter" style="display: none;">
	<div class="filter-count">
		<span class="count"><?php echo $total_count; ?></span>
	</div>

	<ul class="filter-links">
		<li><a href="#" class="current" data-filter="all">All</a></li>
		<li><a href="#" data-filter="fse">Block Editor <span class="count">(<?php echo $block_editor_count; ?>)</span></a></li>
		<!-- <li><a href="#" data-filter="shop">Shop <span class="count">(<?php echo $shop_count; ?>)</span></a></li> -->
		<li><a href="#" data-filter="imported">Imported <span class="count">(<?php echo $imported_count; ?>)</span></a></li>
	</ul>

	<form class="search-form">
		<p class="search-box">
			<label for="wp-filter-search-input">Search</label>
			<input type="search" id="wp-filter-search-input" class="wp-filter-search" placeholder="Search websites...">
		</p>
	</form>
</div>

<div class="websites-browser">

	<?php foreach ($demo_websites as $demo): ?>
		<?php
		$is_imported = ! empty( \BetterBlockEditor\Modules\DemoContent\Trackers\TrackerBase::get_demo_history( $demo['id'] ) );
		if ( $is_imported ) {
			$actions = [ 'remove', 'keep' ];
		} else {
			$actions = ['import'];
		}
		?>
		<div class="websites-item" data-tags="<?php echo implode(' ', $demo['tags']); ?>">
			<?php if ($is_imported): ?>
				<div class="notice inline notice-success notice-alt"><p>Imported</p></div>
			<?php endif; ?>

			<a href="<?php echo esc_url($demo['link']); ?>" class="websites-preview" target="_blank" rel="noopener">
				<img class="websites-thumbnail" alt="<?php echo esc_attr($demo['title']); ?>" src="<?php echo esc_url($demo['screenshot']); ?>">
				<div class="websites-details">
					<span>Preview & partial import</span>
				</div>
			</a>

			<div class="websites-caption">
				<h2><?php echo esc_html($demo['title']); ?></h2>
				<form method="post" action="<?php echo esc_url($step2_url); ?>" class="websites-actions">
					<input type="hidden" name="demo_id" value="<?php echo esc_attr( $demo['id'] ); ?>">
					<?php foreach ($actions as $action): ?>
						<?php if ($action === 'import'): ?>
							<button type="submit" class="button button-primary" data-action="import" name="import_type" value="full_import">Import full template</button>
						<?php elseif ($action === 'keep'): ?>
							<button type="submit" class="button button-primary" data-action="keep">Keep template</button>
						<?php elseif ($action === 'remove'): ?>
							<button type="submit" class="button" data-action="remove">Remove template</button>
						<?php endif; ?>
					<?php endforeach; ?>
				</form>
			</div>
		</div>
	<?php endforeach; ?>

</div>

<?php
require __DIR__ . '/popup.php';
?>
