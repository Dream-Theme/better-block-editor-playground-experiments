<?php
defined( 'ABSPATH' ) || exit;
?>

<div class="wrap">

	<h1>Pre‑made Website Templates</h1>

	<?php
	$step = isset( $_GET['step'] ) ? 'step' . (int) $_GET['step'] : null;
	if ( $step === 'step2' ) {
		require __DIR__ . '/page-step2.php';
	} else {
		require __DIR__ . '/page-step1.php';
	}
	?>

</div>
