<?php

use BetterBlockEditor\Modules\DemoContent\ActionBuilders\ImportContentActionBuilder;
use BetterBlockEditor\Modules\DemoContent\Demo\Factory as DemoFactory;

defined( 'ABSPATH' ) || exit;

$demo_id        = wp_unslash( $_POST['demo_id'] ?? '' );
$demo           = DemoFactory::create( $demo_id );
$action_builder = new ImportContentActionBuilder( $demo, $_POST );

$action_builder->localize_data_to_js();

if ( ! empty( $action_builder->get_error() ) ) {
	echo wp_kses_post( $action_builder->get_error() );

	return;
}
?>

<div class="bbe-import-feedback">
	<?php echo wp_kses_post( $action_builder->get_starting_text() ) ?>
</div>
<div class="bbe-go-back-link hide-if-js">
	<p>
		<?php echo esc_html_x( 'All done.', 'admin', 'the7mk2' ) ?>
	</p>
	<p>
		<?php
		echo '<a id="bbe-demo-visit-site-link" href="' . esc_url( home_url() ) . '">' . esc_html_x( 'Visit site', 'admin', 'the7mk2' ) . '</a>';
		echo ' | ';
		echo '<a href="' . esc_url( BetterBlockEditor\Modules\DemoContent\Module::get_admin_url() ) . '">' . esc_html_x( 'Back to Site Templates', 'admin', 'the7mk2' ) . '</a>';
		?>
	</p>
</div>
